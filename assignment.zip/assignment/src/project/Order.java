package project;
public class Order {
  private MenuItem item;
  private int quantity;
  private Boolean takeaway;
  private String remark;
  
  public Order(MenuItem item, int quantity, Boolean takeaway, String remark) {
    this.item = item;
    this.quantity = quantity;
    this.takeaway = takeaway;
    this.remark = remark;
  }
  
  public MenuItem getItem() {
    return this.item;
  }
  
  public int getQuantity() {
    return this.quantity;
  }
  
  public void setQuantity(int quantity) {
    this.quantity=quantity;
  }
  
  public Boolean getTakeaway(){
    return this.takeaway;
  }
  
  public String getRemark() {
    return this.remark;
  }
}

