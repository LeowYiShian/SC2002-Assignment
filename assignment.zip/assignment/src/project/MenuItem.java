package project;
public class MenuItem{
  
  public enum Category {SETMEAL, BURGER, SIDE, DRINK};
  
  private String name;
  private double price;
  private String description;
  private String branchName;
  private Category category;
  private boolean availability;
  
  public MenuItem(String name, double price, String branchName, String description, Category category, boolean availability){
    this.name = name;
    this.price = price;
    this.branchName = branchName;
    this.description = description;
    this.category = category;
    this.availability = availability;
  }
  
  public String getName() {
   return name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public double getPrice() {
    return price;
  }
  
  public void setPrice(double price) {
    this.price = price;
  }
  
  public String getDescription() {
    return description;
  }
  
  public void setDescription(String description) {
    this.description = description;
  }
  
  public Category getCategory() {
    return category;
  }
  
  public void setCategory(Category category) {
    this.category = category;
  }
  
  public boolean IsAvailable() {
    return availability;
  }
  
  public void setAvailability(boolean availability) {
    this.availability = availability;
  }  
  
}