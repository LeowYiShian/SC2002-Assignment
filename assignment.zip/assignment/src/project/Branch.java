package project;
import java.util.HashMap;
import java.util.Map;
public class Branch {
    private String branchName;
    private String location;
    private StaffList staffList;
    private Map<Integer, OrderList> orderMap;
    private MenuItemList menu;
    private int order_Id = 1;  
    public Branch(String branchName, String location, int staffQuota){
        this.branchName = branchName;
        this.location = location;
        this.staffList = new StaffList(staffQuota);
        this.orderMap = new HashMap<Integer, OrderList>();
        this.menu = new MenuItemList();
    }
  
    public String getName() {
        return branchName;
    }
  
    public void setName(String name) {
        branchName = name;
    }
  
    public String getLocation() {
        return location;
    }
  
    public void setLocation(String loc) {
        location = loc;
    }
  
    public int getorder_Id() {
        return order_Id;
    }
  
    public void increment_order_Id() {
        order_Id++;
    }
  
    public Map<Integer, OrderList> getorderMap(){
      return orderMap;
    }
  
    public StaffList getStaffList() {
        return staffList;
    }
  
    public MenuItemList getMenu() {
        return menu;
    }
  
    public String getBranchName() {
        return branchName;
     }
  
    public Staff login(String loginID, String password) {
        for (Staff staff : staffList.getStaffList()) {
            if (staff.getLoginID().equals(loginID) && staff.getPassword().equals(password)) {
                return staff;
            }
        }
        return null;
    }
  
    public void addOrderList(OrderList orderList, int orderId) {
        orderMap.put(orderId, orderList);
    }  
  
    public void removeOrderList(int orderId) {
        orderMap.remove(orderId);
    }
  
    public void displayOrderDetails(int orderId) {
        OrderList orderList = orderMap.get(orderId);
        if (orderList != null) {
            orderList.displayOrderDetails();
        } else {
            System.out.println("No orders found for orderId " + orderId + "\n");
        }
    }
  
    public void displayNewOrder() {
        if (orderMap.isEmpty()) {
            System.out.println("No order found\n");
        }
        boolean unprocessedOrder = true;
        for (Map.Entry<Integer, OrderList> entry : orderMap.entrySet()) {
            System.out.println("Order Id: "+entry.getKey());
            OrderList orderList = entry.getValue();
            if (orderList.getStatus() == OrderList.OrderStatus.PROCESSING) {
                orderList.displayOrderDetails();
                System.out.println();
                unprocessedOrder=false;
            }
        }
        if(unprocessedOrder){
            System.out.println("No unprocessed order");
        }
    }
  
    public OrderList getOrderById(int orderId) {
        return orderMap.get(orderId);
    }
  
  public void TrackOrderStatus(int orderId) {
      OrderList orderList = getOrderById(orderId);
      if (orderList == null) {
          System.out.println("No orders found for Order ID " + orderId);
          return;
      }
      System.out.println("Status: " + orderList.getStatus());
  }
  
  public void processOrder(int orderId) {
    OrderList orderList = getOrderById(orderId);
    if (orderList == null) {
        System.out.println("No orders found for Order ID " + orderId);
        return;
    }
    orderList.setStatus(OrderList.OrderStatus.READYTOPICKUP);
  }

  public void collectFood(int orderId) {
      OrderList orderList = getOrderById(orderId);
      if (orderList == null) {
          System.out.println("No orders found for Order ID " + orderId);
          return;
      }
      if(orderList.getStatus() == OrderList.OrderStatus.READYTOPICKUP){
        orderList.setStatus(OrderList.OrderStatus.COMPLETED);
        System.out.println("Food successfully collected!");
      }
      else
        System.out.println("Your food has not been processed.");
  }
  
}