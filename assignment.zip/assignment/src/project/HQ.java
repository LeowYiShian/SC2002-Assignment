package project;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;

public class HQ {
  
    private static List<Branch>branchList;
    private static List<Admin>adminList;
    private static List<Staff>allStaffList;
  
    public HQ() {
      branchList = new ArrayList<Branch>();
      adminList = new ArrayList<Admin>();
      allStaffList = new ArrayList<Staff>();
    }
    public static void addBranch(String branchName, String location, int staffQuota) {
      Branch branch = new Branch(branchName, location, staffQuota);
      branchList.add(branch);
  }
    public static List<Admin> getAdminList(){
      return adminList;
    }
  
    public static void addAdmin(Admin admin){
      adminList.add(admin);
    }
  
    public static Admin login(String loginID, String password){
      for (Admin admin:adminList) {
        if (admin.getLoginID().equals(loginID) && admin.getPassword().equals(password)) {
            return admin;
        }
      }
      return null;
    }
  
    public static boolean closeBranch(int index) {
      if (index >= 0 && index < branchList.size()) {
          Branch branch = branchList.get(index);
          branchList.remove(index);
          return true;
      }
      return false;
  }
    public static Branch getBranch(int index){
      if (index >= 0 && index < branchList.size()) {
          return branchList.get(index);
      }
      else {
          return null;
      }
    }
    public static Branch getBranchByName(String name){
      for(Branch branch:branchList){
        if(branch.getName().equals(name)){
          return branch;
        }
      }
      return null;
    }
    public static List<Branch> getBranchList() {
        return branchList;
    }
  
    public static void displayBranch(){
      System.out.println("Branch List:");
      for (int i = 0; i < branchList.size(); i++) {
          System.out.println((i + 1) + ". " + branchList.get(i).getName());
      }
    }
  public static void sortStaff() {
    Collections.sort(allStaffList, new Comparator<Staff>() {
        public int compare(Staff staff1, Staff staff2) {
            int branchComparison = staff1.getBranch().compareTo(staff2.getBranch());
            if (branchComparison != 0) {
                return branchComparison;
            } else {
                return staff1.getName().compareTo(staff2.getName());
            }
        }
    });
  } 
  public static List<Staff> getAllStaffList() {
      allStaffList.clear();
      for (Branch branch : branchList) {
        for(Staff staff : branch.getStaffList().getStaffList()){
          allStaffList.add(staff);
        }
      }
      return allStaffList;
  }
  public static List<Staff> filterbyBranch(String branch){
    List<Staff> filteredList = new ArrayList<Staff>();
      for (Staff staff : allStaffList) {
        if(staff.getBranch().equals(branch)){
          filteredList.add(staff);
        }
      }
    return filteredList;
  }
  public static List<Staff> filterbyGender(Staff.Gender gender){
    List<Staff> filteredList = new ArrayList<Staff>();
      for (Staff staff : allStaffList) {
        if(staff.getGender()==gender){
          filteredList.add(staff);
        }
      }
    return filteredList;
  }
  public static List<Staff> filterbyRole(Staff.Role role){
    List<Staff> filteredList = new ArrayList<Staff>();
      for (Staff staff : allStaffList) {
        if(staff.getRole()==role){
          filteredList.add(staff);
        }
      }
    return filteredList;
  }
  public static List<Staff> filterbyAge(int minAge, int maxAge){
    List<Staff> filteredList = new ArrayList<Staff>();
      for (Staff staff : allStaffList) {
        if(staff.getAge()>=minAge && staff.getAge()<=maxAge){
          filteredList.add(staff);
        }
      }
    return filteredList;
  }
}
