package project;
public class PaymentMethod {
  
    private String name;
  
    public PaymentMethod(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
}

class CreditCard extends PaymentMethod {
    private String cardNumber;
    private String expiryDate;
    private String securityCode;

    public CreditCard(String cardNumber, String expiryDate, String securityCode) {
        super("Credit Card");
        this.cardNumber = cardNumber;
        this.expiryDate = expiryDate;
        this.securityCode = securityCode;
    }
}

class OnlinePayment extends PaymentMethod {
    private String platform;
    private String username;
    private String password;

    public OnlinePayment(String platform, String username, String password) {
        super("Online Payment");
        this.platform = platform;
        this.username = username;
        this.password = password;
    }
}

