package project;
import java.util.Scanner;
import java.util.List;

public class Admin extends Staff{
  
    public Admin(String name, String loginID, Staff.Gender gender, int age, String branch, Staff.Role role, String password){
        super(name,loginID,gender,age, branch,role,password);
    }
                      
  public boolean promoteToBranchManager(String staffName, Branch branch) {
    StaffList staffList = branch.getStaffList();
    Staff staff = staffList.getStaffByName(staffName);
    if(staff==null){
      System.out.println("Staff not found in the branch.");
      return false;
    };
    int currentNumOfManagers = staffList.getNumOfManager();
    int currentNumOfStaffs = staffList.getNumOfStaff();
    if (currentNumOfManagers + 1 <= quotaOfManager(currentNumOfStaffs)) {
      staff.setRole(Staff.Role.MANAGER);
      staffList.setNumOfManager(currentNumOfManagers + 1);
      staffList.setNumOfStaff(currentNumOfStaffs - 1);
      System.out.println(staffName + " is promoted to Manager successfully.");
      return true;
    }
    else {
      System.out.println("Cannot promote to manager. Branch already has maximum number of managers.");
      return false;
    }
  }
  
  public int quotaOfManager(int numOfStaffs) {
    int quota = 0;
    if (numOfStaffs >= 1 && numOfStaffs <= 4){
      quota = 1;
    }
    else if (numOfStaffs >= 5 && numOfStaffs <= 8){
      quota = 2;
    }
    else if (numOfStaffs >= 9 && numOfStaffs <= 15){
      quota = 3;
    }
    return quota;
  }
  
  public boolean transferStaff(String staffName, String sourceBranchName, String destinationBranchName) {
      Branch sourceBranch = null;
      Branch destinationBranch = null;
        for (Branch branch : HQ.getBranchList()) {
            if (branch.getName().equals(sourceBranchName)) {
                sourceBranch = branch;
            }
            if (branch.getName().equals(destinationBranchName)) {
                destinationBranch = branch;
            }
        }
        if (sourceBranch == null || destinationBranch == null) {
            System.out.println("Source or destination branch is not found.");
            return false;
        }
        if(sourceBranch.getStaffList().getNumOfManager()-1 <= quotaOfManager(sourceBranch.getStaffList().getNumOfStaff()-1)||
          destinationBranch.getStaffList().getNumOfManager()+1 >= quotaOfManager(destinationBranch.getStaffList().getNumOfStaff()-1)){
          System.out.println("Cannot transfer staff, staff quota not meet");
          return false;
        }
        Staff staff = sourceBranch.getStaffList().getStaffByName(staffName);
        if (staff == null) {
            System.out.println("Staff is not found in the source branch.");
            return false;
        }
        if (sourceBranch.getStaffList().getStaffList().remove(staff)) {destinationBranch.getStaffList().addStaff(staff);
            return true;
        }
        return false;
  }
  public void filter(){
    List<Staff> filterStaffList = null;
    Scanner sc = new Scanner(System.in);
    System.out.println("1. Filter By branch\n"+
                       "2. Filter by gender\n"+
                       "3. Filter by role\n"+
                       "4. Filter by age\n" +
                       "Enter your choice.");
    int choice = sc.nextInt();
    sc.nextLine();
    switch(choice){
      case 1:
        System.out.println("Enter branch name");
        String branch = sc.nextLine();
        filterStaffList=HQ.filterbyBranch(branch);
        break;
      case 2:
        System.out.println("Enter gender (MALE/FEMALE)");
        String gender_str = sc.nextLine();
        Staff.Gender gender = null;
        if(gender_str.equals("MALE")){
          gender = Staff.Gender.MALE;
        }
        else if(gender_str.equals("FEMALE")){
          gender = Staff.Gender.FEMALE;
        }
        filterStaffList=HQ.filterbyGender(gender);
        break;
      case 3:
        System.out.println("Enter role (STAFF/MANAGER)");
        String role_str = sc.nextLine();
        Staff.Role role = null;
        if(role_str.equals("STAFF")){
          role = Staff.Role.STAFF;
        }
        else if(role_str.equals("MANAGER")){
          role = Staff.Role.MANAGER;
        }
        filterStaffList=HQ.filterbyRole(role);
        break;
      case 4:
        System.out.println("Enter min age");
        int minAge = sc.nextInt();
        System.out.println("Enter max age");
        int maxAge = sc.nextInt();
        filterStaffList=HQ.filterbyAge(minAge,maxAge);
        break;
      default:
      System.out.println("Invalid choice. Please enter a number between 0 and 4.\n");
        break;
    }
    for(Staff staff:filterStaffList){
      System.out.println("Name: " + staff.getName() + "\n" +
               "Gender: " + staff.getGender() + "\n" +
               "Age: " + staff.getAge() + "\n" +
               "Branch: " + staff.getBranch() + "\n" +
               "Role: " + staff.getRole() + "\n");
    }
  }  
}
