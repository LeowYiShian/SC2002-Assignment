package project;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class AdminInterface {
  public static void handler(Admin admin) {
    Scanner sc = new Scanner(System.in);
    System.out.println("\nWelcome, " + admin.getName() + "!");
    boolean exit = false;
    while (!exit) {
      System.out.println("1. Open Branch\n" +
                         "2. Close Branch\n" +
                         "3. Display Branch\n" +
                         "4. Manage Branch\n" +
                         "5. Display All Staff\n" +
                         "6. Filter Staff\n" +
                         "7. Edit Payment\n" +
                         "0. Back\n" +
                         "Enter your choice: ");
      int choice = sc.nextInt();
      sc.nextLine();
      switch (choice) {
        case 1:
          System.out.println("Enter Branch Name:");
          String branchName = sc.nextLine();
          System.out.println("Enter Location:");
          String location = sc.nextLine();
          System.out.println("Enter Staff Quota:");
          int staffQuota = sc.nextInt();
          HQ.addBranch(branchName, location, staffQuota);
          break;
        case 2:
          HQ.displayBranch();
          System.out.println("Enter the branch number to be closed:");
          int a = sc.nextInt();
          HQ.closeBranch(a-1);
          break;
        case 3:
          HQ.displayBranch();
          break;
        case 4:
          System.out.println("Enter the branch number: ");
          int b = sc.nextInt();
          Branch branch = HQ.getBranch(b-1);
          if(branch == null) {
            System.out.println("Branch not found.\n");
          }
          else{
            manageBranch(branch,admin);
          }
          break;
        case 5:
          List<Staff>staffList = HQ.getAllStaffList();
          HQ.sortStaff();
          for(Staff staff : staffList){
            System.out.println("Name: " + staff.getName() + "\n" +
               "Gender: " + staff.getGender() + "\n" +
               "Age: " + staff.getAge() + "\n" +
               "Branch: " + staff.getBranch() + "\n" +
               "Role: " + staff.getRole() + "\n");
          }
          break;
        case 6:
          admin.filter();
          break;
        case 7:
          editPayment();
          break;
        case 0:
          System.out.println("Logging out. Goodbye!\n");
          exit = true;
          break;
        default:
          System.out.println("Invalid choice. Please enter a number between 0 and 7.\n");
      }
    }
  }
  
  public static void editPayment() {
    Scanner sc = new Scanner(System.in);
    int choice;
    boolean exit = false;
    while (!exit) {
      System.out.println("Editing Payment:\n" +
                         "1. Display Payment Methods\n" +
                         "2. Add Payment Method\n" +
                         "3. Remove Payment Method\n" +
                         "0. Back\n" +
                         "Enter your choice: ");
      choice = sc.nextInt();
      sc.nextLine();
      String name;
      switch (choice) {
        case 1:
          Payment.displayPaymentMethods();
          break;
        case 2:
          System.out.print("Enter the payment method type to add: ");
          name = sc.nextLine();
          PaymentMethod methodToAdd = new PaymentMethod(name);
          Payment.addPaymentMethod(methodToAdd);
          break;
        case 3:
          System.out.print("Enter the payment method to remove: ");
          int id = sc.nextInt();
          PaymentMethod paymentMethod = Payment.getPaymentMethod(id);
          if(paymentMethod == null){
          System.out.println("Payment method does not exist.\n");
          }
          else{
            Payment.removePaymentMethod(paymentMethod);
          }
          break;
        case 0:
          System.out.println("Done editing payment.\n");
          exit = true;
          break;
        default:
          System.out.println("Invalid choice. Please enter a number between 0 and 3.\n");
      }
    }
  }
  private static void manageBranch(Branch branch, Admin admin) {
    Scanner sc = new Scanner(System.in);
    boolean exit = false;
      while (!exit) {
        System.out.println("Managing Branch:\n" +
                           "1. Display Staff List\n" +
                           "2. Promote Staff to Branch Manager\n" +
                           "3. Transfer Staff among Branches\n" +
                           "4. Edit Staff Accounts\n" +
                           "0. Back\n" +
                           "Enter your choice: ");
          int choice = sc.nextInt();
          sc.nextLine();
          switch (choice) {
              case 1:
                  StaffList staffList = branch.getStaffList();
                  System.out.println("Number of staff: "+staffList.getNumOfStaff());
                  System.out.println("Staff quota: "+staffList.getStaffQuota());
                  staffList.displayStaffList();
                  break;
              case 2:
                  System.out.println("Enter Staff to be promoted");
                  String StaffToBePromoted = sc.nextLine();
                  admin.promoteToBranchManager(StaffToBePromoted,branch);
                  break;
              case 3:
                  System.out.println("Enter Source Branch");
                  String SourceBranch = sc.nextLine();
                  System.out.println("Enter Staff to be transferred");
                  String StaffToBeTransferred = sc.nextLine();
                  System.out.println("Enter Destination Branch");
                  String DestinationBranch = sc.nextLine();
                  admin.transferStaff(StaffToBeTransferred, SourceBranch, DestinationBranch);
                  break;
              case 4:
                  editStaffAcc(branch);
                  break;
              case 0:
                  exit = true;
                  break;
              default:
                  System.out.println("Invalid choice. Please enter a number between 0 and 4.\n");
          }
      }
  }
  public static void editStaffAcc(Branch branch) {
    Scanner sc = new Scanner(System.in);
    boolean exit = false;
    int choice;
    while (!exit) {
      System.out.println("Editing Staff Account:\n" +
                         "1. Add Staff\n" +
                         "2. Remove Staff\n" +
                         "0. Back\n" +
                         "Enter your choice: ");
      choice = sc.nextInt();
      sc.nextLine();
      String name;
      Staff staff;
      switch (choice) {
        case 1:
          System.out.println("Enter name of staff to be added:");
          name = sc.nextLine();
          System.out.println("Enter login ID:");
          String loginID = sc.nextLine();
          System.out.println("Enter gender (MALE/FEMALE):");
          String gender = sc.nextLine();
          Staff.Gender genderEnum;
          if(gender.equals("MALE")){
            genderEnum = Staff.Gender.MALE;
          }
          else if(gender.equals("FEMALE")){
            genderEnum = Staff.Gender.FEMALE;
          }
          else{
            System.out.println("Error, please make sure you enter MALE or FEMALE correctly (case-sensitive)\n");
            break;
          }
          System.out.println("Enter age:");
          int age = sc.nextInt();
          sc.nextLine();
          System.out.println("Enter role: STAFF/MANAGER");
          String role = sc.nextLine();
          Staff.Role roleEnum;
          if(role.equals("STAFF")){
            roleEnum = Staff.Role.STAFF;
          }
          else if(role.equals("MANAGER")){
            roleEnum = Staff.Role.MANAGER;
          }
          else{
            System.out.println("Error, please make sure you enter STAFF or MANAGER correctly (case-sensitive)\n");
            break;
          }
          System.out.println("The default password of the new staff is \" password \".");
          staff = new Staff(name, loginID, genderEnum, age, branch.getName(), roleEnum, "password");
          branch.getStaffList().addStaff(staff);
          break;
        case 2:
          System.out.println("Enter name of staff to be removed:");
          name = sc.nextLine();
          staff = branch.getStaffList().getStaffByName(name);
          branch.getStaffList().getStaffList().remove(staff);
          break;
        case 0:
          System.out.println("Done editing staff account.\n");
          exit = true;
          break;
        default:
          System.out.println("Invalid choice. Please enter a number between 0 and 2.\n");
      }
    }
  }
}