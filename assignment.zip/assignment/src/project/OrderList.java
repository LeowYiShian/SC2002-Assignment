package project;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalTime;

public class OrderList {
  
  public enum OrderStatus{PROCESSING, READYTOPICKUP, COMPLETED, CANCELLED};
  private List<Order> orders = new ArrayList<Order>();
  private LocalTime readyTime;
  private OrderStatus orderStatus;
  private boolean paid;
  public OrderList(){
    this.orders = new ArrayList<Order>();
    this.orderStatus = OrderStatus.PROCESSING;
    this.readyTime = null;
    this.paid = false;
  }
  public boolean getPaid(){
    return this.paid;
  }
  public void setPaid(){
    this.paid=true;
  }
  public void addOrder(Order order) {
      orders.add(order);
  }
  
  public void removeOrder(Order order) {
      orders.remove(order);
  }
  
  public List<Order> getOrders() {
      return orders;
  }
  
  public void displayOrderDetails() {
      for (Order order : orders) {
          MenuItem item = order.getItem();
          System.out.println("Item: " + item.getName() + "\n" +
          "Quantity: " + order.getQuantity() + "\n" +
           "Takeaway: " + order.getTakeaway() + "\n" +
           "Remark: " + order.getRemark() + "\n"+
           "Status: " + getStatus().name()+ "\n");
      }
  }
  
  public OrderStatus getStatus() {
    return this.orderStatus;
  }
  
  public void setStatus(OrderStatus orderStatus) {
    this.orderStatus = orderStatus;
    if(orderStatus == OrderStatus.READYTOPICKUP){
      setReadyTime();
    }
  }
  
  public LocalTime getReadyTime() {
    return readyTime;
  }
  
  public void setReadyTime() {
    readyTime=LocalTime.now();;
  }
  
  public double getTotalPrice() {
    double totalAmount = 0;
      for (Order order : orders) {
            MenuItem item = order.getItem();
            totalAmount += item.getPrice()*order.getQuantity();
        }
        return totalAmount;
    }
}