package project;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.List;

public class HQ {
  
    private static List<Branch>branchList;
    private static List<Admin>adminList;
    private static StaffList allStaffList;
  
    public HQ() {
      branchList = new ArrayList<Branch>();
      adminList = new ArrayList<Admin>();
      allStaffList = new StaffList(1000);
    }
    public static void addBranch(String branchName, String location, int staffQuota) {
      Branch branch = new Branch(branchName, location, staffQuota);
      branchList.add(branch);
  }
    public static List<Admin> getAdminList(){
      return adminList;
    }
  
    public static void addAdmin(Admin admin){
      adminList.add(admin);
    }
  
    public static Admin login(String loginID, String password){
      for (Admin admin:adminList) {
        if (admin.getLoginID().equals(loginID) && admin.getPassword().equals(password)) {
            return admin;
        }
      }
      return null;
    }
  
    public static boolean closeBranch(String name) {
      for(Branch branch : branchList){
        if(branch.getName().equals(name))
          branchList.remove(branch);
          return true;
      }
      return false;
  }
  public static Branch getBranch(String name){
      for(Branch branch:branchList){
        if(branch.getName().equals(name)){
          return branch;
        }
      }
      return null;
    }
    public static Branch getBranchById(int id){
      for(Branch branch:branchList){
        if(id==0){
          return branch;
        }
        id--;
      }
      return null;
    }
    public static List<Branch> getBranchList() {
        return branchList;
    }
  
    public static void displayBranch(){
      System.out.println("Branch List:");
      for (int i = 0; i < branchList.size(); i++) {
          System.out.println((i + 1) + ". " + branchList.get(i).getName());
      }
    }
  public static void sortStaff() {
    Collections.sort(allStaffList.getStaffList(), new Comparator<Staff>() {
        public int compare(Staff staff1, Staff staff2) {
            int branchComparison = staff1.getBranch().compareTo(staff2.getBranch());
            if (branchComparison != 0) {
                return branchComparison;
            } else {
                return staff1.getName().compareTo(staff2.getName());
            }
        }
    });
  } 
  public static StaffList getAllStaffList() {
      allStaffList.getStaffList().clear();
      for (Branch branch : branchList) {
        for(Staff staff : branch.getStaffList().getStaffList()){
          allStaffList.getStaffList().add(staff);
        }
      }
      return allStaffList;
  }
  public static StaffList filter_method(String branch){
    StaffList filteredList = new StaffList(1000);
      for (Staff staff : allStaffList.getStaffList()) {
        if(staff.getBranch().equals(branch)){
          filteredList.getStaffList().add(staff);
        }
      }
    return filteredList;
  }
  public static StaffList filter_method(Staff.Gender gender){
    StaffList filteredList = new StaffList(1000);
      for (Staff staff : allStaffList.getStaffList()) {
        if(staff.getGender()==gender){
          filteredList.addStaff(staff);
        }
      }
    return filteredList;
  }
  public static StaffList filter_method(Staff.Role role){
    StaffList filteredList = new StaffList(1000);
      for (Staff staff : allStaffList.getStaffList()) {
        if(staff.getRole()==role){
          filteredList.addStaff(staff);
        }
      }
    return filteredList;
  }
  public static StaffList filter_method(int minAge, int maxAge){
    StaffList filteredList = new StaffList(1000);
      for (Staff staff : allStaffList.getStaffList()) {
        if(staff.getAge()>=minAge && staff.getAge()<=maxAge){
          filteredList.addStaff(staff);
        }
      }
    return filteredList;
  }
}
