package project;
public class Staff {  
  public enum Gender {
    MALE, FEMALE
    
  }
  
  public enum Role {
    STAFF, MANAGER, ADMIN
  }
  
  private String name;
  private String loginID;
  private Gender gender;
  private int age;
  private String branch;
  private Role role;
  private String password;

  public Staff(String name, String loginID, Gender gender, int age, String branch, Role role, String password) {
    this.name = name;
    this.loginID = loginID;
    this.gender = gender;
    this.age = age;
    this.branch = branch;
    this.role = role;
    this.password = (password != null && !password.isEmpty()) ? password : "password";
  }
  
  public String getName() {
    return name;
  }
  
  public void setName(String name) {
    this.name = name;
  }

  public String getLoginID() {
    return loginID;
  }
  
  public void setLoginID(String loginID) {
    this.loginID = loginID;
  }

  public Gender getGender() {
    return gender;
  }
  
  public void setGender(Gender gender) {
    this.gender = gender;
  }

  public int getAge() {
    return age;
  }
  
  public void setAge(int age) {
    this.age = age;
  }

  public String getBranch() {
    return branch;
  }
  
  public void setBranch(String branch) {
    this.branch = branch;
  }

  public Role getRole() {
    return role;
  }
  
  public void setRole(Role role) {
    this.role = role;
  }

  public void setPassword(String password) {
    this.password = password;
  }
  
  public String getPassword() {
    return password;
  }
}
