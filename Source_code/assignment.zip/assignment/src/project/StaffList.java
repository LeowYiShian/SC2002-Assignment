package project;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StaffList {
  private List<Staff> staffList;
  private int staffQuota;
  private int numOfStaff;
  private int numOfManager;
  
  public StaffList(int staffQuota) {
    this.staffList = new ArrayList<Staff>();
    this.staffQuota = staffQuota;
    this.numOfStaff = 0;
    this.numOfManager = 0;
  }
  public void setStaffQuota(int quota){
    staffQuota=quota;
  }
  public int getStaffQuota(){
    return staffQuota;
  }
  public void displayStaffList() {
    for(Staff staff : this.staffList){
      System.out.println("Name: " + staff.getName() + "\n" +
         "Gender: " + staff.getGender() + "\n" +
         "Age: " + staff.getAge() + "\n" +
         "Branch: " + staff.getBranch() + "\n" +
         "Role: " + staff.getRole() + "\n");
    }
  }
  public List<Staff> getStaffList() {
    return this.staffList;
  }
  public int getNumOfStaff(){
    return numOfStaff;
  }
  public int getNumOfManager(){
    return numOfManager;
  }
  public void setNumOfStaff(int n) {
    numOfStaff=n;
  }
  public void setNumOfManager(int n) {
    numOfManager=n;
  }
  public Staff getStaffById(String loginID) {
    for (Staff staff : staffList) {
      if (staff.getLoginID().equals(loginID)) {
        return staff;
      }
    }
    return null;
  }
  public Staff getStaffByName(String name) {
    for (Staff staff : staffList) {
      if (staff.getName().equals(name)) {
        return staff;
      }
    }
    return null;
  }
  public void addStaff(Staff staff) {
    if (staffList.size() < staffQuota) {
    if (staff.getRole() == Staff.Role.STAFF) {
      numOfStaff++;
    }
    else if (staff.getRole() == Staff.Role.MANAGER) {
      numOfManager++;
    }
    this.staffList.add(staff);
  }
  else {System.out.println("Cannot add more staff. Staff quota reached.");}
  }
  public void removeStaff(String staffName) {
    Iterator<Staff> iterator = this.staffList.iterator();
      while (iterator.hasNext()) {
        Staff staff = iterator.next();
          if (staff.getName().equals(staffName)) {
            if (staff.getRole() == Staff.Role.STAFF) {
              numOfStaff--;
            }
            else if (staff.getRole() == Staff.Role.MANAGER) {
              numOfManager--;
            }
            iterator.remove();
            return;
          }
      }
      System.out.println("Staff member with name " + staffName + " not found.");
  }
}
