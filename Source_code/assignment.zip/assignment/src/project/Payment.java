package project;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Payment{
  public static List<PaymentMethod> paymentMethods = new ArrayList<PaymentMethod>();

  public Payment (){
    paymentMethods.add(new PaymentMethod("Credit Card"));
    paymentMethods.add(new PaymentMethod("Online Payment"));
  }

  public static void addPaymentMethod(PaymentMethod method) {
      if (!paymentMethods.contains(method)) {
            paymentMethods.add(method);
          System.out.println("Payment method '" + method.getName() + "' added successfully.\n");
      } else {
          System.out.println("Payment method '" + method.getName() + "' already exists.\n");
      }
  }
  
  public static void removePaymentMethod(PaymentMethod method) {
      if (paymentMethods.contains(method)) {
            paymentMethods.remove(method);
          System.out.println("Payment method '" + method.getName() + "' deleted successfully.\n");
      } else {
          System.out.println("Payment method '" + method.getName() + "' does not exist.\n");
      }
  }
  public static PaymentMethod getPaymentMethod(int id){
    int i=0;
    for (PaymentMethod method : paymentMethods){
      if(i==id) return method;
      i++;
    }
    return null;
  }

  public static boolean MakePayment(double total, Scanner sc){
    System.out.printf("Total Amount: %.2f\n" , total); 
    if (selectPaymentMethod(sc)){
      System.out.println("Payment successful!");
      return true;
    }
    else 
      return false;
    
    
  }

  public static void displayPaymentMethods() {
      int i=1;
      System.out.println("Payment Methods:");
      for (PaymentMethod method : paymentMethods){
        System.out.printf("%d. %s%n", i, method.getName());
        i++;
      }
      System.out.println();
  }

public static boolean selectPaymentMethod(Scanner sc){
  displayPaymentMethods();
  System.out.println("Enter payment method:");
  int id = sc.nextInt();
  PaymentMethod selectedMethod = getPaymentMethod(id-1);
  sc.nextLine();
  if(selectedMethod != null){
    switch(selectedMethod.getName()){
      case "Credit Card":
        System.out.println("Enter credit card number:");
        String cardNumber = sc.nextLine();
        System.out.println("Enter credit card expiry date (MM/YY):");
        String expiryDate = sc.nextLine();
        System.out.println("Enter credit card CVV:");
        String cvv = sc.nextLine();
        CreditCard card = new CreditCard(cardNumber, expiryDate, cvv);
        break;
      case "Online Payment":
        System.out.println("Enter Platform:");
        String platform = sc.nextLine();
        System.out.println("Enter Username:");
        String username = sc.nextLine();
        System.out.println("Enter Password:");
        String password = sc.nextLine();
        OnlinePayment onlinePayment = new OnlinePayment(platform, username, password);
        break; 
    }
    return true;
  }
  else
    return false;
}
}
