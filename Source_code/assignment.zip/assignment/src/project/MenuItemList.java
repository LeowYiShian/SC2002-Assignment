package project;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MenuItemList{
  
  private List<MenuItem> menuItems = new ArrayList<MenuItem>();
  
  public MenuItemList() {
    this.menuItems = new ArrayList<MenuItem>();
  }
  
  public void addItem(String name, double price, String branchName, String description, MenuItem.Category category, boolean availability){
    MenuItem item =  new MenuItem(name,price,branchName,description,category,availability);
    menuItems.add(item);    
  }

  public void removeItem (MenuItem item){
    String name = item.getName();
    menuItems.remove(item);
    if(!menuItems.contains(item)){
      System.out.println(name + " is removed successfully");
    }
  }
  
  public List<MenuItem> getmenuItems(){
    return menuItems;
  }
  
  public MenuItem getItem(String name){
    for (MenuItem item : menuItems) {
      if (item.getName().equals(name)) {
        return item;
      }
    }
    return null;
  }
  
  public void displayMenuItemToStaff() {
      sortMenuItems();
      System.out.println("Menu:");
      int index = 1;
      MenuItem.Category currentCategory = null;
      for (MenuItem item : menuItems) {
          if (currentCategory != item.getCategory()) {
              currentCategory = item.getCategory();
              System.out.println("\n" + currentCategory + ":");
              index = 1;
          }
          System.out.println(
              index + ". " + item.getName() + 
              " - Price: $" + item.getPrice() + 
              " - Description: " + item.getDescription() + 
              " - Availability: " + (item.IsAvailable() ? "Available" : "Not Available")
          );
          index++;
      }
  }

  public void displayMenuItemToCustomer(String branchName, Branch branch) {
      sortMenuItems();
      System.out.println("Menu for " + branchName + ":");
      int index = 1;
      MenuItem.Category currentCategory = null;
      for (MenuItem item : menuItems) {
          if (branch.getBranchName().equals(branchName)) {
              if (currentCategory != item.getCategory()) {
                  currentCategory = item.getCategory();
                  System.out.println("\n" + currentCategory + ":");
              }
              if (item.IsAvailable()) {
                  System.out.println(
                      index + ". " + item.getName() + 
                      "\n - Description: " + item.getDescription() + 
                      "\n - Price: $" + item.getPrice());
                  index++;
              }
          }
      }
  }
  
  public void sortMenuItems() {
    Collections.sort(menuItems, new Comparator<MenuItem>() {
      public int compare(MenuItem item1, MenuItem item2) {
        int categoryComparison = item1.getCategory().compareTo(item2.getCategory());
        if (categoryComparison != 0) {
          return categoryComparison;
        }
        return item1.getName().compareTo(item2.getName());
      }
    });
  }
  
}
 